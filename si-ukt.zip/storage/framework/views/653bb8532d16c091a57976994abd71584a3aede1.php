

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="card">
            <?php if($user->id_kelompok_ukt === null ): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda belum mempunyai kelompok UKT. Silahkan melakukan penentuan UKT terlebih dahulu!</h4>
                </div>
            </div>
            <?php elseif($user->kelompok_ukt < $setting->batas_ukt_penurunan ): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda tidak dapat melakukan pengajuan penurunan UKT, karena Anda termasuk kelompok UKT <?php echo e($user->kelompok_ukt); ?>!</h4>
                </div>
            </div>
            <?php elseif($user->status_pengajuan === 'Penangguhan' && $form !== 'Edit'): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda tidak dapat mengisi form penurunan UKT, karena Anda sedang melakukan proses penangguhan UKT!</h4>
                </div>
            </div>
            <?php elseif($user->status_pengajuan === 'Penurunan' && $dataPenurunanUKT !== null && $form !== 'Edit'): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda tidak dapat mengisi form penurunan UKT, karena Anda sedang melakukan proses penurunan UKT!</h4>
                    <a href="/informasi-pengajuan-penurunan-ukt/<?php echo e($dataPenurunanUKT->id_penurunan_ukt); ?>" class="btn btn-primary mt-3">Informasi Pengajuan Penurunan UKT</a>
                </div>
            </div>
            <?php elseif($penentuan!== null && $penentuan->status_laporan === 'Belum'): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda tidak dapat mengisi form penangguhan UKT, karena proses penentuan UKT masih dilakukan!</h4>    
                </div>
            </div>
            <?php elseif($user->status_pengajuan === 'Tidak' && $dataPenurunanUKT === null || $form === 'Edit'): ?>
            <div class="card-header d-flex justify-content-between">
                <div class="header-title">
                    <h4 class="card-title"><?php echo e($subTitle); ?></h4>
                </div>
            </div>
            <div class="card-body">
                <div class="new-user-info">
                    <form action="<?php if($form === 'Tambah'): ?> /pengajuan-penurunan-ukt <?php elseif($form === 'Edit'): ?> /edit-pengajuan-penurunan-ukt/<?php echo e($detail->id_penurunan_ukt); ?> <?php endif; ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nama_mahasiswa">Nama Mahasiswa</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_mahasiswa" name="nama_mahasiswa" value="<?php echo e($user->nama_mahasiswa); ?>" readonly placeholder="Masukkan Nama Lengkap ">
                            <?php $__errorArgs = ['nama_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nim">NIM</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nim" name="nim" value="<?php echo e($user->nim); ?>" readonly placeholder="Masukkan NIM ">
                            <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="program_studi">Program Studi</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="program_studi" name="program_studi" value="<?php echo e($user->prodi); ?>" readonly placeholder="Masukkan Program Studi ">
                            <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nomor_telepon">No. HP</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomor_telepon" name="nomor_telepon" value="<?php echo e($user->nomor_telepon); ?>" readonly placeholder="Masukkan No. HP ">
                            <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-12">
                            <label class="form-label"><strong>Data Tambahan:</strong></label>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="semester">Semester <span class="text-danger">*</span></label>
                            <select name="semester" id="semester" class="selectpicker form-control <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus data-style="py-0" required>
                                <?php if($form === 'Tambah'): ?>
                                    <option>-- Pilih --</option>
                                <?php elseif($form === 'Edit'): ?>
                                    <option value="<?php echo e($detail->semester); ?>"><?php echo e($detail->semester); ?></option>
                                <?php endif; ?>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                            </select>
                            <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="alamat_rumah">Alamat Rumah Lengkap (Untuk Kebutuhan Survey)</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['alamat_rumah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat_rumah" name="alamat_rumah" value="<?php if($form == 'Tambah'): ?><?php echo e(old('alamat_rumah')); ?><?php elseif($form == 'Edit'): ?><?php echo e($detail->alamat_rumah); ?><?php endif; ?>" placeholder="Masukkan Alamat Rumah Lengkap" required>
                            <?php $__errorArgs = ['alamat_rumah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if($setting->form_penurunan_sktm == 1): ?>
                            <div class="form-group col-md-6">
                                <label class="form-label" for="sktm">SKTM (Surat Keterangan Tidak Mampu) <span class="text-danger">* PDF</span></label>
                                <input type="file" class="form-control <?php $__errorArgs = ['sktm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sktm" name="sktm" placeholder="Masukkan SKTM" required>
                                <?php $__errorArgs = ['sktm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>
                        <?php if($setting->form_penurunan_khs == 1): ?>
                            <div class="form-group col-md-6">
                                <label class="form-label" for="khs">KHS (Semester Berjalan) <span class="text-danger">* PDF</span></label>
                                <input type="file" class="form-control <?php $__errorArgs = ['khs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="khs" name="khs" placeholder="Masukkan KHS" required>
                                <?php $__errorArgs = ['khs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>
                        <?php if($setting->form_penurunan_struk_listrik == 1): ?>
                            <div class="form-group col-md-6">
                                <label class="form-label" for="struk_listrik">Struk Listrik <span class="text-danger">* PDF</span></label>
                                <input type="file" class="form-control <?php $__errorArgs = ['struk_listrik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="struk_listrik" name="struk_listrik" placeholder="Masukkan Struk Listrik" required>
                                <?php $__errorArgs = ['struk_listrik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>
                        <?php if($setting->form_penurunan_foto_rumah == 1): ?>
                            <div class="form-group col-md-6">
                                <label class="form-label" for="foto_rumah">Foto Rumah <span class="text-danger">* PDF</span></label>
                                <input type="file" class="form-control <?php $__errorArgs = ['foto_rumah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto_rumah" name="foto_rumah" placeholder="Masukkan Foto Rumah" required>
                                <?php $__errorArgs = ['foto_rumah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>
                        <?php if($setting->form_penurunan_slip_gaji == 1): ?>
                            <div class="form-group col-md-6">
                                <label class="form-label" for="slip_gaji">Slip Gaji (Opsional) <span class="text-danger">* PDF</span></label>
                                <input type="file" class="form-control <?php $__errorArgs = ['slip_gaji'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slip_gaji" name="slip_gaji" placeholder="Masukkan Foto Rumah" required>
                                <?php $__errorArgs = ['slip_gaji'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>
                        <?php if($setting->form_penurunan_surat_pengajuan == 1): ?>
                            <div class="form-group col-md-6">
                                <label class="form-label" for="surat_pengajuan">Surat Pengajuan (Anda buat sendiri dengan format bebas dengan tujuan ke Wadir II) <span class="text-danger">* PDF</span></label>
                                <input type="file" class="form-control <?php $__errorArgs = ['surat_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="surat_pengajuan" name="surat_pengajuan" placeholder="Masukkan Surat Pengajuan" required>
                                <?php $__errorArgs = ['surat_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                        <br>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-danger">Reset</button>
                        <?php if($form == 'Edit'): ?>
                            <a href="/informasi-pengajuan-penurunan-ukt/<?php echo e($detail->id_penurunan_ukt); ?>"" class="btn btn-secondary">Kembali</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <?php elseif($user->status_pengajuan === 'Tidak' && $dataPenurunanUKT !== null): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda tidak dapat mengisi form penurunan UKT, karena Anda sudah pernah melakukan proses penurunan UKT!</h4>
                    <a href="/informasi-pengajuan-penurunan-ukt/<?php echo e($dataPenurunanUKT->id_penurunan_ukt); ?>" class="btn btn-primary mt-3">Informasi Pengajuan Penurunan UKT</a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-ukt\resources\views/mahasiswa/penurunanUKT/formPengajuan.blade.php ENDPATH**/ ?>