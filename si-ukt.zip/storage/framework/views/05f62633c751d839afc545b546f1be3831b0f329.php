

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <div class="header-title">
                    <h4 class="card-title"><?php echo e($subTitle); ?></h4>
                </div>
            </div>
            <div class="card-body">
                <div class="new-user-info">
                    <form action="<?php if($form === 'Tambah'): ?> /tambah-mahasiswa <?php elseif($form === 'Edit'): ?> /edit-mahasiswa/<?php echo e($detail->id_mahasiswa); ?> <?php endif; ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nama_mahasiswa">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_mahasiswa" name="nama_mahasiswa" value="<?php if($form === 'Tambah'): ?><?php echo e(old('nama_mahasiswa')); ?><?php elseif($form === 'Edit' || $form === 'Detail'): ?><?php echo e($detail->nama_mahasiswa); ?><?php endif; ?>" <?php if($form === 'Detail'): ?> disabled <?php endif; ?> autofocus placeholder="Masukkan Nama Lengkap ">
                            <?php $__errorArgs = ['nama_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nim">NIM <span class="text-danger">*</span></label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nim" name="nim" value="<?php if($form === 'Tambah'): ?><?php echo e(old('nim')); ?><?php elseif($form === 'Edit' || $form === 'Detail'): ?><?php echo e($detail->nim); ?><?php endif; ?>"  <?php if($form === 'Detail'): ?> disabled <?php endif; ?> placeholder="Masukkan NIM">
                            <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="tahun_angkatan">Tahun Angkatan <span class="text-danger">* Contoh: 2020</span></label>
                            <input type="number" class="form-control <?php $__errorArgs = ['tahun_angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tahun_angkatan" name="tahun_angkatan" value="<?php if($form === 'Tambah'): ?><?php echo e(old('tahun_angkatan')); ?><?php elseif($form === 'Edit' || $form === 'Detail'): ?><?php echo e($detail->tahun_angkatan); ?><?php endif; ?>"  <?php if($form === 'Detail'): ?> disabled <?php endif; ?> placeholder="Masukkan Tahun Angkatan" min="2000" max="2099">
                            <?php $__errorArgs = ['tahun_angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nomor_telepon">Nomor Telepon <span class="text-danger">*</span></label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomor_telepon" name="nomor_telepon" value="<?php if($form === 'Tambah'): ?><?php echo e(old('nomor_telepon')); ?><?php elseif($form === 'Edit' || $form === 'Detail'): ?><?php echo e($detail->nomor_telepon); ?><?php endif; ?>"  <?php if($form === 'Detail'): ?> disabled <?php endif; ?> placeholder="Masukkan Nomor Telepon">
                            <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="prodi">Program Studi <span class="text-danger">*</span></label>
                            <select name="prodi" id="prodi" class="selectpicker form-control <?php $__errorArgs = ['prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-style="py-0" <?php if($form === 'Detail'): ?> disabled <?php endif; ?>>
                                <?php if($form === 'Tambah'): ?>
                                    <option>-- Pilih --</option>    
                                <?php elseif($form === 'Edit' || $form === 'Detail'): ?>
                                    <option value="<?php echo e($detail->prodi); ?>"><?php echo e($detail->prodi); ?></option>
                                <?php endif; ?>
                                <?php $__currentLoopData = $dataProdi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->program_studi); ?>"><?php echo e($item->program_studi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="email">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php if($form === 'Tambah'): ?><?php echo e(old('email')); ?><?php elseif($form === 'Edit' || $form === 'Detail'): ?><?php echo e($detail->email); ?><?php endif; ?>" <?php if($form === 'Detail'): ?> disabled <?php endif; ?> placeholder="Masukkan Email ">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="password">Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" <?php if($form === 'Detail'): ?> disabled <?php endif; ?> placeholder="Masukkan Password ">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="foto">Foto <span class="text-danger">*</span></label>
                            <input type="file" class="form-control <?php $__errorArgs = ['foto_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="preview_image" name="foto_user" <?php if($form === 'Detail'): ?> disabled <?php endif; ?>>
                            <?php $__errorArgs = ['foto_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-md-6">
                            <label class="form-label" for="status_pengajuan">Status Pengajuan <span class="text-danger">*</span></label>
                            <select name="status_pengajuan" id="status_pengajuan" class="selectpicker form-control <?php $__errorArgs = ['status_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-style="py-0" <?php if($form === 'Detail'): ?> disabled <?php endif; ?>>
                                <?php if($form === 'Tambah'): ?>
                                    <option>-- Pilih --</option>    
                                <?php elseif($form === 'Edit' || $form === 'Detail'): ?>
                                    <option value="<?php echo e($detail->status_pengajuan); ?>"><?php echo e($detail->status_pengajuan); ?></option>
                                <?php endif; ?>
                                <option value="Tidak">Tidak</option>
                                <option value="Penangguhan">Penangguhan</option>
                                <option value="Penurunan">Penurunan</option>
                            </select>
                            <?php $__errorArgs = ['status_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if($form === 'Edit'): ?>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="status_mahasiswa">Status Mahasiswa <span class="text-danger">*</span></label>
                            <select name="status_mahasiswa" id="status_mahasiswa" class="selectpicker form-control <?php $__errorArgs = ['status_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-style="py-0" <?php if($form === 'Detail'): ?> disabled <?php endif; ?>>
                                <?php if($form === 'Tambah'): ?>
                                    <option>-- Pilih --</option>    
                                <?php elseif($form === 'Edit' || $form === 'Detail'): ?>
                                    <option value="<?php echo e($detail->status_mahasiswa); ?>"><?php echo e($detail->status_mahasiswa); ?></option>
                                <?php endif; ?>
                                <option value="Aktif">Aktif</option>
                                <option value="Tidak Aktif">Tidak Aktif</option>
                            </select>
                            <?php $__errorArgs = ['status_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php endif; ?>
                        <?php if($form === 'Edit' && $detail->id_kelompok_ukt !== null): ?>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="id_kelompok_ukt">Kelompok UKT</label>
                            <select name="id_kelompok_ukt" id="id_kelompok_ukt" class="selectpicker form-control <?php $__errorArgs = ['id_kelompok_ukt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-style="py-0" <?php if($form === 'Detail'): ?> disabled <?php endif; ?>>  
                                <?php if($form === 'Edit' || $form === 'Detail'): ?>
                                    <option value="<?php echo e($detail->id_kelompok_ukt); ?>"><?php echo e($detail->kelompok_ukt); ?> | <?php echo e('Rp '.number_format($detail->nominal, 0, ',', '.')); ?></option>
                                <?php endif; ?>
                                <?php $__currentLoopData = $dataUKT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->program_studi == $detail->prodi): ?>
                                        <option value="<?php echo e($item->id_kelompok_ukt); ?>"><?php echo e($item->kelompok_ukt); ?> | <?php echo e('Rp '.number_format($item->nominal, 0, ',', '.')); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['kelompok_ukt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                        <br>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-danger">Reset</button>
                        <a href="/daftar-mahasiswa" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-ukt\resources\views/bagianKeuangan/kelolaMahasiswa/form.blade.php ENDPATH**/ ?>