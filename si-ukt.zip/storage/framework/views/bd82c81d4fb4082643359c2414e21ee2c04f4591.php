

<?php $__env->startSection('content'); ?>
<section>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-box">
                <div class="form-title-wrap">
                    <div>
                        <h3 class="title"><?php echo e($subTitle); ?></h3>
                        <p class="font-size-14">Form <?php echo e($subTitle); ?></p>
                    </div>
                </div>
                <div class="form-content">
                    <div class="contact-form-action">
                        <form <?php if($form === 'Tambah'): ?> action="/tambah-faq"  <?php else: ?> action="/edit-faq/<?php echo e($faq->id_faq); ?>" <?php endif; ?> method="Post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Nama</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="nama" placeholder="Masukkan Nama" <?php if($form === 'Edit'): ?> value="<?php echo e($faq->nama); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($faq->nama); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('nama')); ?>" <?php endif; ?> autofocus>
                                        </div>
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Email</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="email" name="email" placeholder="Masukkan Email" <?php if($form === 'Edit'): ?> value="<?php echo e($faq->email); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($faq->email); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('email')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Pertanyaan</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="pertanyaan" placeholder="Masukkan Pertanyaan" <?php if($form === 'Edit'): ?> value="<?php echo e($faq->pertanyaan); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($faq->pertanyaan); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('pertanyaan')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['pertanyaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Jawaban</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="jawaban" placeholder="Masukkan Jawaban" <?php if($form === 'Edit'): ?> value="<?php echo e($faq->jawaban); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($faq->jawaban); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('jawaban')); ?>" <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['jawaban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Tampil?</label>
                                        <div class="form-group select-contain w-100">
                                            <select class="select-contain-select" name="tampil" <?php if($form === 'Detail'): ?>  disabled <?php endif; ?>>
                                                <?php if($form === 'Edit' || $form === 'Detail'): ?>
                                                <option value="<?php echo e($faq->tampil); ?>"><?php echo e($faq->tampil); ?></option>
                                                <?php else: ?>
                                                <option value="">--Pilih--</option>
                                                <?php endif; ?>
                                                <option value="Ya">Ya</option>
                                                <option value="Tidak">Tidak</option>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['tampil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($form !== 'Detail'): ?>
                            <div class="btn-box pt-3 pb-4">
                                <center>
                                    <button type="submit" class="theme-btn w-50">Simpan</button>
                                </center>
                            </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div><!-- end form-box -->
        </div><!-- end col-lg-12 -->
    </div><!-- end row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/admin/faq/form.blade.php ENDPATH**/ ?>