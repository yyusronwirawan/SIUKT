

<?php $__env->startSection('content'); ?>

<?php
    date_default_timezone_set('Asia/Jakarta');

    $currentDate = date('Y-m-d'); 
    $tambahHari = '+'.$setting->batas_tanggal_angsuran.' days';
    $batasTanggalAngsuran  = date('d F Y', strtotime($tambahHari, strtotime($currentDate)));

    $denda = $user->nominal * $setting->persen_denda / 100;
    $totalNominal = $user->nominal + $denda;
    $angsuranPertama = $totalNominal * $setting->persen_angsuran_pertama / 100;
    $angsuranKedua = $totalNominal - $angsuranPertama;

?>

<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="card">
            <?php if($user->id_kelompok_ukt === null ): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda belum mempunyai kelompok UKT. Silahkan melakukan penentuan UKT terlebih dahulu!</h4>
                </div>
            </div>
            <?php elseif($user->kelompok_ukt < $setting->batas_ukt_penangguhan ): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda tidak dapat melakukan pengajuan penangguhan UKT, karena Anda termasuk kelompok UKT <?php echo e($user->kelompok_ukt); ?>!</h4>
                </div>
            </div>
            <?php elseif($user->status_pengajuan === 'Penangguhan' && $form !== 'Edit'): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda tidak dapat mengisi form penangguhan UKT, karena Anda sedang melakukan proses penangguhan UKT!</h4>
                </div>
            </div>
            <?php elseif($user->status_pengajuan === 'Penurunan'): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda tidak dapat mengisi form penangguhan UKT, karena Anda sedang melakukan proses penurunan UKT!</h4>
                </div>
            </div>
            <?php elseif($penentuan!== null && $penentuan->status_laporan === 'Belum'): ?>
            <div class="card-header d-flex justify-content-between mb-4">
                <div class="header-title text-center">
                    <h4 class="card-title ">Anda tidak dapat mengisi form penangguhan UKT, karena proses penentuan UKT masih dilakukan!</h4>
                </div>
            </div>
            <?php elseif($user->status_pengajuan === 'Tidak' || $form === 'Edit'): ?>
            <div class="card-header d-flex justify-content-between">
                <div class="header-title">
                    <h4 class="card-title"><?php echo e($subTitle); ?></h4>
                </div>
            </div>
            <div class="card-body px-4" style="margin-bottom: -50px;">
                <?php if(session('fail')): ?>
                    <div class="col-lg-12">
                        <div class="alert bg-danger text-white alert-dismissible">
                            <span>
                                <svg width="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.9852 21.606C11.9852 21.606 19.6572 19.283 19.6572 12.879C19.6572 6.474 19.9352 5.974 19.3192 5.358C18.7042 4.742 12.9912 2.75 11.9852 2.75C10.9792 2.75 5.26616 4.742 4.65016 5.358C4.03516 5.974 4.31316 6.474 4.31316 12.879C4.31316 19.283 11.9852 21.606 11.9852 21.606Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>                                    <path d="M13.864 13.8249L10.106 10.0669" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>                                    <path d="M10.106 13.8249L13.864 10.0669" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>                                </svg>                            
                                <?php echo e(session('fail')); ?>

                            </span>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="new-user-info">
                    <form action="<?php if($form === 'Tambah'): ?> /pengajuan-penangguhan-ukt <?php elseif($form === 'Edit'): ?> /edit-pengajuan-penangguhan-ukt/<?php echo e($detail->id_penangguhan_ukt); ?> <?php endif; ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nama_mahasiswa">Nama Mahasiswa</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_mahasiswa" name="nama_mahasiswa" value="<?php echo e($user->nama_mahasiswa); ?>" readonly placeholder="Masukkan Nama Lengkap ">
                            <?php $__errorArgs = ['nama_mahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nim">NIM</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nim" name="nim" value="<?php echo e($user->nim); ?>" readonly placeholder="Masukkan NIM ">
                            <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="program_studi">Program Studi</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="program_studi" name="program_studi" value="<?php echo e($user->prodi); ?>" readonly placeholder="Masukkan Program Studi ">
                            <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nomor_telepon">No. HP</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomor_telepon" name="nomor_telepon" value="<?php echo e($user->nomor_telepon); ?>" readonly placeholder="Masukkan No. HP ">
                            <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-12">
                            <label class="form-label"><strong>Orang Tua/Wali dari Mahasiswa Politeknik Negeri Subang:</strong></label>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nama_orang_tua">Nama Orang Tua/Wali <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_orang_tua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_orang_tua" name="nama_orang_tua" value="<?php if($form === 'Tambah'): ?><?php echo e(old('nama_orang_tua')); ?><?php elseif($form === 'Edit'): ?><?php echo e($detail->nama_orang_tua); ?><?php endif; ?>" autofocus placeholder="Masukkan Nama Orang Tua/Wali">
                            <?php $__errorArgs = ['nama_orang_tua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="alamat_orang_tua">Alamat <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['alamat_orang_tua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat_orang_tua" name="alamat_orang_tua" value="<?php if($form === 'Tambah'): ?><?php echo e(old('alamat_orang_tua')); ?><?php elseif($form === 'Edit'): ?><?php echo e($detail->alamat_orang_tua); ?><?php endif; ?>" placeholder="Masukkan Alamat">
                            <?php $__errorArgs = ['alamat_orang_tua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nomor_telepon_orang_tua">No. HP <span class="text-danger">*</span></label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nomor_telepon_orang_tua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomor_telepon_orang_tua" name="nomor_telepon_orang_tua" value="<?php if($form === 'Tambah'): ?><?php echo e(old('nomor_telepon_orang_tua')); ?><?php elseif($form === 'Edit'): ?><?php echo e($detail->nomor_telepon_orang_tua); ?><?php endif; ?>" placeholder="Masukkan No. HP">
                            <?php $__errorArgs = ['nomor_telepon_orang_tua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-12">
                            <label class="form-label"><strong>Data Tambahan:</strong></label>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="nominal_ukt">Nominal UKT</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nominal_ukt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nominal_ukt" name="nominal_ukt" value="<?php echo e($user->nominal); ?>" readonly placeholder="Masukkan Nominal UKT ">
                            <?php $__errorArgs = ['nominal_ukt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="denda">Nominal Denda (<?php echo e($setting->persen_denda); ?>% dari Nominal UKT)</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['denda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="denda" name="denda" value="<?php echo e($user->nominal * $setting->persen_denda / 100); ?>" readonly placeholder="Masukkan Nominal Denda ">
                            <?php $__errorArgs = ['denda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="semester">Semester <span class="text-danger">*</span></label>
                            <select name="semester" id="semester" class="selectpicker form-control <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-style="py-0">
                                <?php if($form === 'Tambah'): ?>
                                    <option>-- Pilih --</option>
                                <?php elseif($form === 'Edit'): ?>
                                    <option value="<?php echo e($detail->semester); ?>"><?php echo e($detail->semester); ?></option>
                                <?php endif; ?>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                            </select>
                            <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="alasan">Alasan Penangguhan UKT <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['alasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alasan" name="alasan" value="<?php if($form === 'Tambah'): ?><?php echo e(old('alasan')); ?><?php elseif($form === 'Edit'): ?><?php echo e($detail->alasan); ?><?php endif; ?>" placeholder="Masukkan Alasan Penangguhan UKT ">
                            <?php $__errorArgs = ['alasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="angsuran_pertama">Angsuran Pertama (Rp) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control <?php $__errorArgs = ['angsuran_pertama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="angsuran_pertama" name="angsuran_pertama" value="<?php if($form === 'Tambah'): ?><?php echo e($angsuranPertama); ?><?php elseif($form === 'Edit'): ?><?php echo e($detail->angsuran_pertama); ?><?php endif; ?>" readonly placeholder="Masukkan Angsuran Pertama ">
                            <?php $__errorArgs = ['angsuran_pertama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div><div class="form-group col-md-6">
                            <label class="form-label" for="angsuran_kedua">Angsuran Kedua (Rp) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control <?php $__errorArgs = ['angsuran_kedua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="angsuran_kedua" name="angsuran_kedua" value="<?php if($form === 'Tambah'): ?><?php echo e($angsuranKedua); ?><?php elseif($form === 'Edit'): ?><?php echo e($detail->angsuran_kedua); ?><?php endif; ?>" readonly placeholder="Masukkan Angsuran Kedua ">
                            <?php $__errorArgs = ['angsuran_kedua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-12">
                            <label class="form-label"><strong>Batas tanggal angsuran <?php echo e($batasTanggalAngsuran); ?></strong></label>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="tanggal_angsuran_pertama">Tanggal Angsuran Pertama <span class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php $__errorArgs = ['tanggal_angsuran_pertama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_angsuran_pertama" name="tanggal_angsuran_pertama" value="<?php if($form === 'Tambah'): ?><?php echo e(old('tanggal_angsuran_pertama')); ?><?php elseif($form === 'Edit'): ?><?php echo e($detail->tanggal_angsuran_pertama); ?><?php endif; ?>" placeholder="Masukkan Tanggal Angsuran Pertama ">
                            <?php $__errorArgs = ['tanggal_angsuran_pertama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="tanggal_angsuran_kedua">Tanggal Angsuran Kedua <span class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php $__errorArgs = ['tanggal_angsuran_kedua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_angsuran_kedua" name="tanggal_angsuran_kedua" value="<?php if($form === 'Tambah'): ?><?php echo e(old('tanggal_angsuran_kedua')); ?><?php elseif($form === 'Edit'): ?><?php echo e($detail->tanggal_angsuran_kedua); ?><?php endif; ?>" placeholder="Masukkan Tanggal Angsuran Kedua ">
                            <?php $__errorArgs = ['tanggal_angsuran_kedua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="form-label" for="jenis_wawancara">Jenis Wawancara <span class="text-danger">*</span></label>
                            <select name="jenis_wawancara" id="jenis_wawancara" class="selectpicker form-control <?php $__errorArgs = ['jenis_wawancara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required data-style="py-0">
                                <?php if($form === 'Tambah'): ?>
                                    <option>-- Pilih --</option>
                                <?php elseif($form === 'Edit'): ?>
                                    <option value="<?php echo e($detail->jenis_wawancara); ?>"><?php echo e($detail->jenis_wawancara); ?></option>
                                <?php endif; ?>
                                <option value="Online">Online</option>
                                <option value="Offline">Offline</option>
                            </select>
                            <?php $__errorArgs = ['jenis_wawancara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                        <br>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-danger">Reset</button>
                        <a href="/riwayat-pengajuan-penangguhan-ukt" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-ukt\resources\views/mahasiswa/penangguhanUKT/formPengajuan.blade.php ENDPATH**/ ?>